function changePed(pedName)
    local model = GetHashKey(pedName)

    -- Request the model
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(500)
    end

    -- Set the player's ped
    SetPlayerModel(PlayerId(), model)
    SetModelAsNoLongerNeeded(model)
end

-- Register the command
RegisterCommand('ped', function(source, args)
    if #args > 0 then
        local pedName = args[1]
        changePed(pedName)
    else
        print("Usage: /ped <pedName>")
    end
end, false)
