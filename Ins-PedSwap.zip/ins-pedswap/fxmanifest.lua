fx_version 'cerulean'
game 'gta5'

author 'Instant Mods'
description 'Instant Mods Ped Swap Script!'
version '1.0.0'

client_script 'client.lua'
